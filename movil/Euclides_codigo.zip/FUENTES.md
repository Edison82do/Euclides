# FUENTES PEDAGÓGICAS DE EUCLIDES

> **Regla (Carlos, 5 oct 2026):** las fuentes que usaba el agente Hermes se tienen en cuenta.
> Antes de planear un paso se mira AQUÍ qué dice cada fuente de ese tema; las nuevas se añaden.
> Una cita entra solo si se ha leído (si no se pudo abrir, se dice).

## 1. Las fuentes de base (las que usaba Hermes, del 3 al 4 oct)

| Fuente | De qué sirve | Dónde se usó |
|---|---|---|
| **NCETM — Primary Mastery Professional Development** (Reino Unido). Spine 1 *Number, addition and subtraction*; Spine 2 *Multiplication and division* | **El orden de la enseñanza, segmento a segmento.** Es la fuente que más usó Hermes (74 citas) | 4.1, 5.1 (composición), 5.2 (aumentación), 5.4 (reducción), 5.5 (diferencia: «the third and final»), 6.1, 6.2 (*unitising*), 6.3 (*Numbers 10 to 100*), 7.2 (bridging 10), 7.3 (columnas) |
| **Clements & Sarama — *Learning Trajectories in Early Mathematics*** (2009) y learningtrajectories.org | Las **trayectorias**: los niveles por los que pasa un niño (conteo, subitizing, sumar y restar) | 0.2, 0.3, 1.0, 3.4, 4.1, 4.2 |
| **Gelman & Gallistel — *The Child's Understanding of Number*** (1978); **Gelman & Meck** (1983) | Los **principios del conteo** (uno a uno, orden estable, cardinal, abstracción, orden irrelevante) | 2.1–2.6 |
| **Fuson** (1988); Bermejo et al. (2004) | La regla de la **última palabra** (cardinal) y la secuencia de contar | 2.1, 2.3 |
| **Wynn** (1990, 1992); Le Corre et al. (2006); **Sarnecka & Carey** (2008) | Los «conocedores de subconjuntos» (one-, two-, three-knowers): saber contar ≠ saber cuántos | 2.2, 2.3, 2.4, 4.2 |
| **Frye et al.** | Errores de conteo y cardinalidad | 2.3 |
| **Oak National Academy** (lecciones) | Contar grupos grandes por decenas y unidades; hacer diez | 5.4, 6.2, 6.3, 7.2, 7.3 |
| **White Rose Education** | La reducción se enseña primero | 5.4 |
| **NZ Maths** | Valor de posición; los nombres «raros» (once, doce…, quinientos) | 6.5, 7.3 |
| **BBC Bitesize** | Partir en decenas y unidades | 6.5 |
| **EEF** (Education Endowment Foundation) | «Contar desde» es más eficiente que «contar todo» | 7.1 |
| **Number Sense Maths** — *Achieving fluency in addition and subtraction facts*; **Gray y Tall**; Thornton (1978) | Fluidez sin memorizar a ciegas; los que cuentan siempre se quedan atrás | 7.2 |
| **Achieve the Core — Progressions (NBT K–5)** | Restar con y sin descomponer; las columnas | 7.4, 7.5 |
| **Singapur — CPA** (Concreto–Pictórico–Abstracto; Chang, Lee & Koay, NIE 2017; Bruner) | Primero lo concreto, luego el dibujo, luego el símbolo | 0.2 y el método |
| Piaget, Montessori | Contexto histórico (conservación; material concreto) | investigación del 3 oct |
| DREME/Stanford; Nguyen et al. (2017) | Lo que los niños saben del conteo; errores típicos | investigación del 3 oct |

## 2. Las fuentes añadidas el 5 oct (Claude)

| Fuente | De qué sirve | Dónde se usó |
|---|---|---|
| **Common Core State Standards**, grados 1–2 (1.OA, 2.OA) | Qué se espera en cada curso, con ejemplos | memoria (2.OA.B.2), plan pedagógico, P.5 |
| **Progressions for the CCSS — K–5 Counting & Cardinality and OA** (el mismo equipo que la de NBT que usaba Hermes) | **Niveles 1-2-3** (contar todo → contar desde → convertir en uno más fácil); «contar desde el **mayor** aunque sea el segundo»; «contar hacia arriba para restar es más fácil que hacia atrás y refuerza que la resta es un sumando desconocido»; «= siempre significa **es el mismo número que**» | P.5, P.6, E.0 |
| **Carpenter, Fennema, Franke — CGI**; Carpenter, Franke & Levi — *Thinking Mathematically* (2003) | Los 11 tipos de problemas; frases verdadero/falso y con hueco | R.1, E.0–E.2 |
| **Knuth, Alibali, McNeil et al.** (2006, 2008); Falkner, Levi & Carpenter | El `=` operacional vs relacional (8 + 4 = __ + 5 → 12 o 17) | E.2 |
| **Baroody** (fases contar → razonar → dominio); **NRC** *Adding It Up* (2001); **Steinberg** (1985); **Siegler** | La memoria llega después; una estrategia tarda 2–4 lecciones | memoria, técnicas, la regla de velocidad |
| **Jitendra; Fuchs** (instrucción por esquemas); Pólya | Resolver problemas por su estructura, no por palabras clave | R.1 |
| **McGraw-Hill** — resumen de investigación de estrategias de hechos | Orden: dobles → casi dobles → hacer diez; «think addition» | técnicas, P.6 |

## 3. Lo que dicen las fuentes de lo que viene (comprobado el 5 oct)

- **NCETM, segmento 1.7** (*Addition and subtraction: strategies within 10*, Year 1): *«Addition is
  commutative: when the order of the addends is changed, the sum remains the same.»* → P.5.
- **NCETM, segmento 1.5**: *«The equals symbol, =, can be used to show equivalence between the whole
  and the sum of the parts.»* — el `=` nace como **equivalencia**, no como «da». → E.0.
- **NCETM, segmento 1.12** (Year 2): *Subtraction as difference* (ya usado en la 5.5). → P.6.
- **NCETM, Spine 2**: 2.1 contar, *unitising* y monedas (Y1) → 2.2 grupos iguales → 2.3 tabla del 2
  y conmutativa → 2.4 tablas del 10 y del 5, factores 0 y 1 → 2.5 conmutativa, dobles y mitades →
  2.6 división cuotitiva y partitiva (Y2). → N.1, M.0, M.1.
- **Clements & Sarama**, trayectoria *Adding and Subtracting* (edades 6–7): *Counting Strategies*
  (contar desde; 1.OA.8) → *Part-Whole* (combinaciones conocidas; 1.OA.4; el «? + 6 = 11» solo por
  tanteo) → *Numbers-in-Numbers* (parte y todo a la vez; «start unknown» contando; 1.OA.3) →
  *Deriver* («7 + 7 es 14, así que 7 + 8 es 15»; 1.OA.6). Euclides ya tiene *Deriver* (casi dobles).

- **Pensamiento relacional** (Carpenter et al. 2003, 2005; Kızıltoprak y Yavuzsoy Köse 2017, en
  «Relational thinking: the bridge between arithmetic and algebra»): tres niveles — calcular los dos
  lados → calcular y ver la relación → ver la relación sin calcular (57 + 22 = 58 + 21). → E.0, E.2.

- **NCETM 2.1** (*Counting, unitising and coins*, Year 1): «we can count efficiently by counting in
  groups of two / ten / five».  **Common Core 2.NBT.A.2** (contar de 5, 10 y 100 en 100),
  **2.NBT.B.8** (sumar o restar 10 o 100 mentalmente), **2.OA.C.3** (par o impar emparejando o de 2
  en 2), **2.OA.C.4** (filas y columnas, hasta 5 × 5, con sumas). → N.1, M.0.

- **NCETM 2.2** (*Structures: multiplication representing equal groups*): grupos iguales o
  desiguales; decir cuántos grupos y cuántos en cada uno; suma repetida; multiplicación; grupos de
  cero y de uno. **Common Core 3.OA.A.1**: 5 × 7 = 5 grupos de 7. → M.1.

- **NCETM 2.3** (tabla del 2; factor y producto; los factores en cualquier orden), **2.4** (tablas del
  10 y del 5; factores 0 y 1), **2.5** (dos lecturas de la misma multiplicación; dobles; la mitad es
  lo contrario del doble; la del 10 es el doble de la del 5). → M.2.

- **NCETM 2.6** (*Structures: quotitive and partitive division*): agrupar y repartir, las dos contando
  de divisor en divisor; a veces con resto; atajos (tablas, mitad); dividendo 0, igual al divisor,
  divisor 1. **Common Core 3.OA.B.6**: la división como factor desconocido. → M.3.

- **Common Core 3.OA** (3.º): A.3 problemas de × y ÷ (grupos iguales, filas, medidas), A.4 el número
  desconocido en × y ÷, B.5 propiedades como estrategias, C.7 soltura hasta 100, D.8 dos pasos con la
  letra como hueco. **NCETM Spine 2, Year 3–4**: 2.7 (tablas del 2, 4 y 8), 2.8 (3, 6 y 9), 2.9 (7),
  2.10 (multiplicar y dividir; la distributiva). → el plan ajustado (E.4, R.2, M.4–M.6, E.5).

- **Instrucción por esquemas** para × y ÷ (Jitendra; Xin): el esquema de **grupos iguales** (cuántos
  grupos, cuántos en cada uno, total); la operación la decide la casilla que falta, no las palabras
  clave. **Singapur, el modelo de barras**. → R.2.

- **NCETM 2.7** (tablas del 2, 4 y 8): la del 4 es el doble de la del 2, la del 8 el doble de la del 4;
  seguidos se diferencian en 4 / 8; reglas de divisibilidad entre 2, 4 y 8. → M.4.

- **NCETM 2.8** (tablas del 3, 6 y 9): la del 6 es el doble de la del 3; la del 9, el triple de la del
  3; reglas de divisibilidad entre 3, 6 y 9. → M.5.

- **NCETM 2.9** (tabla del 7; par/impar del producto; números cuadrados; divisibilidad) y **2.10**
  (la multiplicación es conmutativa y la división no; la distributiva: partir un factor; hechos más
  allá de las tablas). **Common Core 3.OA.B.5** (8 × 7 = 8 × 5 + 8 × 2) y **3.OA.C.7**. → M.6.

- **Common Core 3.OA.D.8** (problemas de dos pasos con las cuatro operaciones, representados con una
  ecuacion con **una letra** en lugar de lo desconocido; valorar si la respuesta es razonable con
  calculo mental y **estimacion redondeando**). Su nota: sin parentesis, **el orden de siempre**
  (primero × y ÷, luego + y −). **Pólya** (trabajar hacia atras: deshacer). Singapur/Jitendra: un
  esquema y luego otro. → E.5.  La estimacion redondeando (**3.NBT.A.1**) queda para el paso siguiente.

- **Common Core 3.NBT.A.1** (redondear a la decena o centena más cercana usando el valor de posición).
  La *Progression* de base diez y las guías de los estados (Utah *Core Guide* 3.º): se entiende en la
  **recta numérica** (entre qué dos está, la mitad del camino, de cuál está más cerca); la regla «5 o
  más sube» es un atajo posterior; la mitad justa sube **por convenio**. Error documentado: redondear
  en cadena (247 → 250 → 300). → N.2.  Es el requisito de la estimación de 3.OA.D.8 (→ E.6).

- **Common Core 3.OA.D.8** (segunda mitad): valorar si la respuesta es **razonable** con cálculo mental
  y estimación, incluido el redondeo. Estimar = redondear y hacer la cuenta fácil; caza los errores
  grandes (la llevada olvidada, cifras fuera de sitio), no los pequeños: **razonable no es correcta**.
  La banda (cuánto se pudo mover cada número al redondear) hace que «cerca» no sea a ojo. → E.6.

- **NCETM Spine 3** (fracciones; leído el 6 oct). **3.1**: un todo se divide en partes iguales o
  desiguales; con una parte igual y cuántas hay se construye el todo. **3.2**: una parte igual es una
  fracción unitaria y tiene nombre; se aplica a cantidades; «cuanto mayor el denominador, menor la
  fracción»; el todo se saca sumando la fracción unitaria. **3.3**: las no unitarias son varias
  unitarias iguales; numerador = denominador es un entero; son números de la recta; mismo denominador →
  manda el numerador; mismo numerador → manda el denominador (al revés). **3.4**: con el mismo
  denominador se suman/restan los numeradores; restar de un entero: escribirlo como b/b.
  **Common Core 3.NF.A.1–3**. → F.1, F.2, F.3.
- **NCETM por años** (Spines 1 y 2): 4.º = 1.22 (el 1000 y cuatro cifras), 1.23–1.24 (décimas,
  centésimas), 2.10–2.17 (distributiva, tablas 11 y 12, resto, ×/÷ 10 y 100, multiplicación y división
  cortas, área y perímetro); 5.º = 1.26 (hasta un millón), 1.27 (negativos), 2.18–2.22 (factores,
  primos…); 6.º = 1.30, 2.23–2.30. → el plan «Años escolares».

- **NCETM 1.22** (*Composition and calculation: 1,000 and four-digit numbers*, Year 4; leído el 6 oct):
  diez centenas hacen 1000 (y 100 decenas, 1000 unidades); sumar o restar múltiplos de 100 da múltiplos
  de 100; los números de más de mil tienen una estructura que permite ordenar, componer y descomponer;
  redondear; lo de tres cifras sirve para cuatro; 1000 = 2 × 500 = 4 × 250 = 5 × 200.
  **Common Core 4.NBT.A.1–3** (valor de posición; leer, escribir, forma desarrollada; comparar mirando
  las cifras de cada sitio; redondear a cualquier sitio). → N.3.

- **NCETM 2.11** (*Times tables: 11 and 12*, Year 4): la del 11 con la distributiva, 10 + 1; la del 12,
  10 + 2; la del 12 es el doble de la del 6; reglas de divisibilidad entre 11 y 12. → M.7.
- **NCETM 2.12** (*Division with remainders*): agrupar y repartir, a veces con resto; el resto es parte
  de la ecuación; si el dividendo es múltiplo del divisor no hay resto; **el resto siempre es menor que
  el divisor**; en los problemas, el resto se **interpreta** (redondear arriba, abajo, o usarlo). → M.8.
- **NCETM 2.13** (*×/÷ por 10 y 100*): «diez veces más» es × 10; × 10 pone un cero detrás; ÷ 10 a un
  múltiplo de 10 le quita el cero; × 100 dos ceros (= × 10 dos veces); si un factor se hace 10 veces
  mayor, el producto también (y el dividendo / el cociente). → M.9.

- **NCETM 2.14** (*Multiplication: partitioning leading to short multiplication*, Year 4): la
  distributiva por sitios (decenas y unidades; luego centenas) y los productos parciales; después el
  algoritmo de la multiplicación corta, de derecha a izquierda, reagrupando si una columna da diez o
  más. **Common Core 4.NBT.B.5**. → M.10.
- **NCETM 2.15** (*Division: partitioning leading to short division*): partir el dividendo por sitios,
  dividir cada parte y sumar los cocientes parciales, **cambiando** lo que sobra de las decenas por
  unidades; después el algoritmo de la división corta, de **izquierda a derecha**. **Common Core
  4.NBT.B.6**. → M.11.

## Enlaces
- NCETM 2.9: https://www.ncetm.org.uk/classroom-resources/primm-209-times-tables-7-and-patterns-withinacross-times-tables/
- NCETM 2.10: https://www.ncetm.org.uk/classroom-resources/primm-210-connecting-multiplication-and-division-and-the-distributive-law/
- NCETM 2.8: https://www.ncetm.org.uk/classroom-resources/primm-208-times-tables-3-6-and-9-and-the-relationship-between-them/
- NCETM 2.7: https://www.ncetm.org.uk/classroom-resources/primm-207-times-tables-2-4-and-8-and-the-relationship-between-them/
- Common Core 3.OA: https://www.thecorestandards.org/Math/Content/3/OA/
- NCETM 2.6: https://www.ncetm.org.uk/classroom-resources/primm-206-structures-quotitive-and-partitive-division/
- NCETM 2.3: https://www.ncetm.org.uk/classroom-resources/primm-203-times-tables-groups-of-2-and-commutativity-part-1/
- NCETM 2.4: https://www.ncetm.org.uk/classroom-resources/primm-204-times-tables-groups-of-10-and-of-5-and-factors-of-0-and-1/
- NCETM 2.5: https://www.ncetm.org.uk/classroom-resources/primm-205-commutativity-part-2-doubling-and-halving/
- NCETM 2.2: https://www.ncetm.org.uk/classroom-resources/primm-202-structures-multiplication-representing-equal-groups/
- NCETM 2.1: https://www.ncetm.org.uk/classroom-resources/primm-201-counting-unitising-and-coins/
- Common Core 2.OA: https://www.thecorestandards.org/Math/Content/2/OA/
- Common Core 2.NBT: https://www.thecorestandards.org/Math/Content/2/NBT/
- Relational thinking (ERIC): https://files.eric.ed.gov/fulltext/EJ1156327.pdf
- NCETM Spine 1: https://www.ncetm.org.uk/teaching-for-mastery/mastery-materials/primary-mastery-professional-development/number-addition-and-subtraction/
- NCETM 1.5: https://www.ncetm.org.uk/classroom-resources/primm-105-additive-structures-introduction-to-aggregation-and-partitioning/
- NCETM 1.7: https://www.ncetm.org.uk/classroom-resources/primm-107-addition-and-subtraction-strategies-within-10/
- NCETM Spine 2: https://www.ncetm.org.uk/teaching-for-mastery/mastery-materials/primary-mastery-professional-development/multiplication-and-division/
- NCETM unitising: https://www.ncetm.org.uk/features/what-is-unitising-and-why-is-it-important/
- NCETM 1.11 bridging 10: https://www.ncetm.org.uk/classroom-resources/primm-111-addition-and-subtraction-bridging-10/
- Progression CC & OA K–5: https://mathematicalmusings.org/wp-content/uploads/2011/05/ccss_progression_cc_oa_k5_2011_05_302.pdf
- Progression NBT K–5: https://achievethecore.org/content/upload/ccss_progression_nbp_k5_2015_03_16.pdf
- Clements & Sarama (alineación CCSS): https://www.learningtrajectories.org/documents/1599247251013.pdf
- Common Core 1.OA: https://www.thecorestandards.org/Math/Content/1/OA/
- Knuth et al. 2008: https://alibalilab.wiscweb.wisc.edu/wp-content/uploads/sites/371/2018/02/KnuthAlibaliHattikudurMcNeilStephens2008.pdf
- Number Sense Maths: https://numbersensemaths.com/media/1841/achieving-fluency-in-addition-and-subtraction-facts-article.pdf
- Oak National: https://www.thenational.academy/teachers/lessons/addition-by-bridging-through-10
- BBC Bitesize: https://www.bbc.co.uk/bitesize/articles/zncq4xs
- Utah Core Guide 3.º (NBT): https://schools.utah.gov/curr/mathematics/_mathematics_/_core/_math_core_guides_tab_/CoreGuidesGrade3NumberOperations.pdf
- Common Core 3.NBT: https://www.thecorestandards.org/Math/Content/3/NBT/
- NCETM Spine 3 (fracciones): https://ncetm.org.uk/teaching-for-mastery/mastery-materials/primary-mastery-professional-development/fractions/
- NCETM Spine 1: https://ncetm.org.uk/teaching-for-mastery/mastery-materials/primary-mastery-professional-development/number-addition-and-subtraction/
- NCETM Spine 2: https://ncetm.org.uk/teaching-for-mastery/mastery-materials/primary-mastery-professional-development/multiplication-and-division/
