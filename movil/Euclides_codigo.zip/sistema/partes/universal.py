# -*- coding: utf-8 -*-
"""
Euclides - EL RESOLVEDOR UNIVERSAL, PRIMERA FASE: EL MODELO Y EL LECTOR SIMBOLICO (fase U.1 del plan U, 8 oct 2026).

Este archivo es UNA PARTE del motor (ver sistema/partes/__init__.py).

Plan U (diario/2026-10-08-PLAN-U-volverlo-universal.md): ante algo escrito con simbolos que NINGUN paso preparo, el
sistema lo LEE (un solo lector), lo pone en un MODELO (las cantidades que faltan, las relaciones entre ellas, lo que se
pide) y lo RESUELVE con lo que ya sabe, sin recetas de ninguna familia de problemas:

  1. CALCULAR DESPEJANDO: una relacion en la que falta UNA sola cantidad.  Si sale una vez, se DESHACE de fuera hacia
     dentro (trabajar hacia atras, Polya; es lo de E.5).  Si sale varias veces, se cuentan los TROZOS (la barra de
     NCETM 1.31: x = y y z = 2 x y -> 1 + 1 + 2 = 4 trozos de y) y se deshace.
  2. SUSTITUIR: si ninguna relacion tiene una sola cantidad, una que este dicha con las otras (x = y; o aislada
     deshaciendo: a + b = 1/2 -> a = 1/2 - b) se pone en las demas: quedan menos cantidades que faltan.
  3. COMPROBAR: al final, los numeros se ponen en TODAS las relaciones de partida (no en las transformadas).
Las cuentas las hace el NUMERO comun (numero.py), que a su vez se las pide a las piezas de siempre.  Con un
presupuesto de pasos (conocimiento/universal.kn): un humano no da cien vueltas.

El lector amplia el de letra.py (el orden de siempre y los parentesis) con: varias letras, varias relaciones con ';',
fracciones (1/2), decimales (4.5 o 4,5), negativos (-3, x = -2, 3 x (-2)), 2n = 2 x n.  La 'x' es POR entre dos
cosas y LETRA en los demas sitios.
"""

import re

_U_PREFIJO = re.compile(r"^resolver\s*:?\s*")
_U_TOKEN = re.compile(r"\d+\s*/\s*\d+(?![\d.,])|\d+(?:[.,]\d+)?|[a-z]|[()+\-:=;?_/]")
_U_FUERTES = ("x", ":")


class _UNoSale(Exception):
    """El resolvedor no llega: 'conclusion' dice como (todavia_no, ninguna, no_se_puede)."""
    def __init__(self, conclusion, porque):
        Exception.__init__(self, porque)
        self.conclusion = conclusion
        self.porque = porque


def _u_limpio(texto):
    t = texto.lower().strip().replace("−", "-").replace("×", " x ").replace("*", " x ").replace("÷", ":")
    t = t.replace("¿", "").rstrip(".").strip()
    return _U_PREFIJO.sub("", t).strip()


def es_orden_resolver(texto):
    return bool(re.match(r"^resolver(\s*:|\s)", texto.lower().strip()))


# ------------------------------------------------------------- 1. LEER: los simbolos, uno a uno

_U_DE = re.compile(r"(\d+\s*/\s*\d+|\d+[.,]\d+)\s+de\s+(?=[\d(a-z?_])")


def _u_tokens(t):
    t = _U_DE.sub(r"\1 x ", t)                         # 3/4 de 20 = 3/4 x 20 (F.1; 5.NF.B.4): 'de' es POR
    if re.search(r"[a-z]{2,}", t):
        return None                                      # hay palabras: eso es de U.3 (el lector de palabras)
    crudos = _U_TOKEN.findall(t)
    if "".join(crudos).replace(" ", "") != re.sub(r"\s+", "", t):
        return None                                      # hay algo que no es de una expresion
    fin_de_cosa = ("num", "letra", ")")
    principio_de_cosa = ("num", "letra", "(")
    clases = []
    for c in crudos:
        if c[0].isdigit():
            clases.append(("num", c))
        elif c in "?_":
            clases.append(("letra", "?"))
        elif c.isalpha():
            clases.append(("letra", c))                  # 'x' se decide abajo, mirando a los lados
        elif c == "/":
            clases.append(("op", ":"))
        elif c in "+-:":
            clases.append(("op", c))
        else:
            clases.append((c, c))
    out = []
    for i, tok in enumerate(clases):
        if tok == ("letra", "x") and out and out[-1][0] in fin_de_cosa and i + 1 < len(clases) \
                and clases[i + 1][0] in principio_de_cosa:
            tok = ("op", "x")                            # entre dos cosas: es POR
        if out and out[-1][0] in fin_de_cosa and tok[0] in principio_de_cosa:
            if (out[-1][0], tok[0]) in (("num", "letra"), ("num", "("), ("letra", "("), (")", "("), (")", "letra")):
                out.append(("op", "x"))                  # 2n = 2 x n;  2(a + 1) = 2 x (a + 1)
            else:
                return None                              # '3 4' o 'a b': no se sabe que es
        out.append(tok)
    return out


def _u_arbol(toks):
    """El arbol de una expresion, con el orden de siempre: primero x y :, luego + y -; el '-' de delante es negativo."""
    quedan = list(toks)

    def ver():
        return quedan[0] if quedan else (None, None)

    def atomo():
        if not quedan:
            raise ValueError("falta algo al final")
        t = quedan.pop(0)
        if t[0] == "num":
            return ("num", _nu_leer(t[1]))
        if t[0] == "letra":
            return ("letra", t[1])
        if t[0] == "(":
            e = suma()
            if not quedan or quedan.pop(0)[0] != ")":
                raise ValueError("falta cerrar un parentesis")
            return ("par", e)
        raise ValueError("no entiendo '%s' donde va un numero" % t[1])

    def unario():
        if ver() == ("op", "-"):
            quedan.pop(0)
            e = unario()
            return ("num", _nu_opuesto(e[1])) if e[0] == "num" else ("neg", e)
        return atomo()

    def producto():
        e = unario()
        while ver()[0] == "op" and ver()[1] in _U_FUERTES:
            op = quedan.pop(0)[1]
            e = ("op", op, e, unario())
        return e

    def suma():
        e = producto()
        while ver()[0] == "op" and ver()[1] in "+-":
            op = quedan.pop(0)[1]
            e = ("op", op, e, producto())
        return e

    e = suma()
    if quedan:
        raise ValueError("sobra algo al final")
    return e


def _u_leer(texto):
    """El MODELO: {'cantidades': las letras en el orden en que salen, 'relaciones': [(izq, der)], 'expresion': arbol
    (si no hay '=')}.  ValueError si no se deja leer."""
    t = _u_limpio(texto)
    toks = _u_tokens(t)
    if not toks:
        raise ValueError("no es una expresion escrita con numeros, letras y + - x : ( ) = ;")
    trozos, actual = [], []
    for tok in toks:
        if tok[0] == ";":
            trozos.append(actual)
            actual = []
        else:
            actual.append(tok)
    trozos.append(actual)
    trozos = [tr for tr in trozos if tr]
    if not trozos:
        raise ValueError("no hay nada que leer")
    modelo = {"cantidades": [], "relaciones": [], "expresion": None, "texto": t}
    for tr in trozos:
        iguales = [k for k, tok in enumerate(tr) if tok[0] == "="]
        if not iguales:
            if len(trozos) > 1:
                raise ValueError("con ';' cada trozo tiene que ser una relacion (con un =)")
            modelo["expresion"] = _u_arbol(tr)
        elif len(iguales) > 1:
            raise ValueError("una relacion lleva UN signo =")
        else:
            k = iguales[0]
            modelo["relaciones"].append((_u_arbol(tr[:k]), _u_arbol(tr[k + 1:])))
        for tok in tr:
            if tok[0] == "letra" and tok[1] not in modelo["cantidades"]:
                modelo["cantidades"].append(tok[1])
    if modelo["expresion"] is not None and modelo["cantidades"]:
        raise ValueError("una expresion con letras y sin '=' no se puede calcular")
    return modelo


def es_expresion_simbolica(texto):
    """Lo lee entero el lector simbolico, y hay algo que hacer: una cuenta (dos numeros o mas) o una relacion."""
    if es_orden_resolver(texto):
        return True
    try:
        m = _u_leer(texto)
    except (ValueError, _NuNoSale):
        return False
    if m["relaciones"]:
        return True
    return m["expresion"][0] in ("op", "par", "neg") and _u_hay_cuenta(m["expresion"])


def _u_la_puerta_no_llega(salida):
    """'no_entiendo' o 'todavia_no' si lo que contesto una puerta vieja es eso; si no, None."""
    if salida.startswith("NO ENTIENDO"):
        return "no_entiendo"
    lineas = salida.strip().splitlines()
    if lineas and lineas[-1].strip() == "RESULTADO: todavia_no":
        return "todavia_no"
    return None


def _u_le_toca_al_resolvedor(texto, vieja, saber):
    """LA RED DE SEGURIDAD (U.1, ampliada en U.2 tras la revision de U.1): una puerta vieja no llega ('no entiendo' o
    'todavia no') y el lector simbolico lo lee entero.  Si el resolvedor llega a una respuesta comprobada (hecho, o
    ninguna porque las relaciones se contradicen), contesta el.  Con 'todavia no', solo si hay una RELACION con letras: el 'todavia no' de una cuenta sin
    letras es respetar el ano (12 : 3 + 1, 2/3 x 3/4), no un problema de forma."""
    if not vieja or not es_expresion_simbolica(texto):
        return False
    if vieja == "todavia_no":
        try:
            m = _u_leer(texto)
        except (ValueError, _NuNoSale):
            return False
        if not m["relaciones"] or not m["cantidades"]:
            return False
    try:
        r = decidir_resolver(texto, saber)
    except Exception:
        return False
    if r["conclusion"] == "ninguna":             # ninguna porque se contradicen, si; probando en orden solo es ninguna
        return not r.get("probado")              # con numeros para contar (podria haberla con decimales): no basta
    return r["conclusion"] == "hecho"


def _u_hay_cuenta(e):
    if e[0] == "op":
        return True
    if e[0] in ("par", "neg"):
        return _u_hay_cuenta(e[1])
    return False


# ------------------------------------------------------------- el arbol: escribirlo, sus letras, sustituir

def _u_texto(e):
    if e[0] == "num":
        return _nu_texto(e[1])
    if e[0] == "letra":
        return e[1]
    if e[0] == "par":
        return "(%s)" % _u_texto(e[1])
    if e[0] == "neg":
        dentro = _u_texto(e[1])
        return "-%s" % (dentro if e[1][0] in ("letra", "par") else "(%s)" % dentro)
    izq, der = _u_texto(e[2]), _u_texto(e[3])
    if e[3][0] == "num" and _nu_texto(e[3][1]).startswith("-"):
        der = "(%s)" % der
    return "%s %s %s" % (izq, e[1], der)


def _u_letras(e):
    if e[0] == "letra":
        return [e[1]]
    if e[0] == "num":
        return []
    if e[0] in ("par", "neg"):
        return _u_letras(e[1])
    out = _u_letras(e[2])
    out.extend(_u_letras(e[3]))
    return out


def _u_letras_rel(rel):
    out = _u_letras(rel[0])
    out.extend(_u_letras(rel[1]))
    return out


def _u_distintas(lista):
    out = []
    for x in lista:
        if x not in out:
            out.append(x)
    return out


def _u_poner(e, letra, valor):
    """Pone 'valor' (un arbol) donde esta la letra.  Si no es una cosa sola, entre parentesis."""
    if e[0] == "letra":
        if e[1] != letra:
            return e
        return valor if valor[0] in ("num", "letra", "par") else ("par", valor)
    if e[0] == "num":
        return e
    if e[0] in ("par", "neg"):
        return (e[0], _u_poner(e[1], letra, valor))
    return ("op", e[1], _u_poner(e[2], letra, valor), _u_poner(e[3], letra, valor))


def _u_poner_todas(e, valores):
    for letra, v in valores.items():
        e = _u_poner(e, letra, ("num", v))
    return e


def _u_rel_texto(rel):
    return "%s = %s" % (_u_texto(rel[0]), _u_texto(rel[1]))


def _u_nombre(letra):
    return "el hueco" if letra == "?" else letra


# ------------------------------------------------------------- calcular (con el numero comun)

def _u_valor(e, saber, pasos):
    """Calcula un arbol sin letras, en el ORDEN DE SIEMPRE (el arbol ya lo tiene)."""
    if e[0] == "num":
        return e[1]
    if e[0] == "par":
        return _u_valor(e[1], saber, pasos)
    if e[0] == "neg":
        return _nu_opuesto(_u_valor(e[1], saber, pasos))
    if e[0] == "letra":
        raise _UNoSale("todavia_no", "falta saber cuanto vale %s" % _u_nombre(e[1]))
    if e[1] == ":":
        m = _u_media(e, saber, pasos)
        if m is None:
            m = _u_mitad_de_un_producto(e, saber, pasos)
        if m is not None:
            return m
    if e[1] in ("+", "-"):
        m = _u_divisor_comun(e, saber, pasos)
        if m is not None:
            return m
    a = _u_valor(e[2], saber, pasos)
    b = _u_valor(e[3], saber, pasos)
    return _u_cuenta(e[1], a, b, saber, pasos)


# ------------------------------------------------------------- M.20: la MEDIA (NCETM 2.26), con las piezas de 'media'

def _u_sumandos(e):
    """Los valores de una suma de enteros sin signo (v1 + v2 + ... + vk), en el orden en que vienen; o None."""
    if e[0] == "num":
        x = e[1]
        if x[0] == "+" and x[2] == 1 and x[3] == "entero":
            return [x[1]]
        return None
    if e[0] == "op" and e[1] == "+":
        a, b = _u_sumandos(e[2]), _u_sumandos(e[3])
        if a is None or b is None:
            return None
        a.extend(b)
        return a
    return None


def _u_media(e, saber, pasos):
    """(v1 + ... + vk) : k, con el divisor igual a CUANTOS valores hay (contados): es la MEDIA.  Se pide a las
    piezas de 'media' (se elige por el costo: nivelar si estan cerca, juntar y repartir si no).  Lo que sale se pasa al
    numero comun (lo que toca a cada uno y lo que sobro repartido).  None si no es una media o no sale: como antes."""
    if e[2][0] != "par" or e[3][0] != "num":
        return None
    k = e[3][1]
    if k[0] != "+" or k[2] != 1 or k[3] != "entero":
        return None
    valores = _u_sumandos(e[2][1])
    if valores is None or decir(len(valores), saber) != decir(k[1], saber):
        return None
    r = aplicar("media", {"valores": valores, "partes": k[1]}, saber)
    if r["conclusion"] != "hecho":
        return None
    res = r["resultado"]
    q, resto, sub = res["valor"], res["resto"], []
    try:
        if not resto:
            v = _NU_CERO if q == 0 else ("+", q, 1, "entero")
        elif q == 0:
            v = _nu_simple(("+", resto, k[1], "fraccion"), saber, sub)
        else:
            v = _nu_sumar(("+", q, 1, "entero"), ("+", resto, k[1], "fraccion"), saber, sub)
    except (_NuNoSale, KeyError):
        return None
    nombres = ["%d" % x for x in valores]
    pasos.append("LA MEDIA de %s y %s: repartir por igual entre los %d (NCETM 2.26); %s"
                 % (", ".join(nombres[:-1]), nombres[-1], k[1], r["pieza"]["nombre"]))
    pasos.extend("     %s" % p for p in res["pasos"])
    if resto:
        pasos.append("     %d y %d/%d%s" % (q, resto, k[1], "" if q == 0 else " = %s" % _nu_texto(v)))
    pasos.append("     compruebo: %s" % res["vuelta"])
    pasos.append("%s : %d = %s" % (_u_texto(e[2]), k[1], _nu_texto(v)))
    return v


# ------------------------------------------------------------- M.24: la MITAD DE UN PRODUCTO (NCETM 2.30), con las piezas de 'mitad_de_un_producto'

def _u_mitad_de_un_producto(e, saber, pasos):
    """a x b : 2 con dos enteros (el area del triangulo, base x altura : 2): se pide a las piezas de
    'mitad_de_un_producto' (se elige por el costo: partir antes el factor par; o multiplicar y partir).  Lo que sale (y
    el medio que sobra) se pasa al numero comun.  None si no es eso o no sale: como antes (el mismo numero)."""
    if _u_entero_sin_signo(e[3]) != 2 or decir(_u_entero_sin_signo(e[3]), saber) != "dos":
        return None
    izq = e[2]
    while izq[0] == "par":
        izq = izq[1]
    if izq[0] != "op" or izq[1] != "x":
        return None
    a, b = _u_entero_sin_signo(izq[2]), _u_entero_sin_signo(izq[3])
    if a is None or b is None:
        return None
    r = aplicar("mitad_de_un_producto", {"a": a, "b": b}, saber)
    if r["conclusion"] != "hecho":
        return None
    res = r["resultado"]
    q, resto, sub = res["valor"], res["resto"], []
    try:
        if not resto:
            v = ("+", q, 1, "entero")
        elif q == 0:
            v = _nu_simple(("+", 1, 2, "fraccion"), saber, sub)
        else:
            v = _nu_sumar(("+", q, 1, "entero"), ("+", 1, 2, "fraccion"), saber, sub)
    except (_NuNoSale, KeyError):
        return None
    pasos.append("LA MITAD DE UN PRODUCTO, %d x %d : 2 (NCETM 2.30): %s" % (a, b, r["pieza"]["nombre"]))
    pasos.extend("     %s" % p for p in res["pasos"])
    if resto:
        pasos.append("     %d y 1/2%s" % (q, "" if q == 0 else " = %s" % _nu_texto(v)))
    pasos.append("     compruebo: %s" % res["vuelta"])
    pasos.append("%s : 2 = %s" % (_u_texto(e[2]), _nu_texto(v)))
    return v


# ------------------------------------------------------------- M.22: el DIVISOR COMUN (NCETM 2.28), con las piezas de 'divisor_comun'

def _u_entero_sin_signo(e):
    """El entero (sin signo) de una hoja del arbol, o None."""
    while e[0] == "par":
        e = e[1]
    if e[0] == "num" and e[1][0] == "+" and e[1][2] == 1 and e[1][3] == "entero":
        return e[1][1]
    return None


def _u_cadena(e):
    """Una cadena de + y - sin parentesis (a + b - c ...): los terminos con su signo, en el orden en que vienen."""
    if e[0] == "op" and e[1] in ("+", "-"):
        c = _u_cadena(e[2])
        c.append([e[1], e[3]])
        return c
    return [["+", e]]


def _u_divisor_comun(e, saber, pasos):
    """a : d + b : d - ... con TODOS los terminos divisiones de enteros entre el MISMO d: se pide a las piezas de
    'divisor_comun' (se elige por el costo: juntar lo de arriba y repartir UNA vez; o dividir cada una y juntar).  Lo que
    sale (lo que toca y lo que sobra) se pasa al numero comun.  None si no es eso o no sale: como antes."""
    terminos, d = [], None
    for signo, t in _u_cadena(e):
        if t[0] != "op" or t[1] != ":":
            return None
        a, b = _u_entero_sin_signo(t[2]), _u_entero_sin_signo(t[3])
        if a is None or b is None:
            return None
        if d is None:
            d = b
        elif decir(b, saber) != decir(d, saber):
            return None
        terminos.append([signo, a])
    r = aplicar("divisor_comun", {"terminos": terminos, "divisor": d}, saber)
    if r["conclusion"] != "hecho":
        return None
    res = r["resultado"]
    q, resto, sub = res["valor"], res.get("resto", 0), []
    try:
        sobra = ("+", resto, d, "fraccion")
        if resto and d in _NU_POTENCIAS:          # M.23: entre 10, 100 o 1000 lo que sobra baja detras del punto
            sobra = _nu_dividir(("+", resto, 1, "entero"), ("+", d, 1, "entero"), saber, sub)
        if not resto:
            v = _NU_CERO if q == 0 else ("+", q, 1, "entero")
        elif q == 0:
            v = _nu_simple(sobra, saber, sub)
        else:
            v = _nu_sumar(("+", q, 1, "entero"), sobra, saber, sub)
    except (_NuNoSale, KeyError):
        return None
    pasos.append("EL MISMO DIVISOR, %d (NCETM 2.28): %s" % (d, r["pieza"]["nombre"]))
    if r["pieza"]["id"] == "juntar_sobre_el_divisor_comun":
        arriba = ["%d" % terminos[0][1]]
        arriba.extend("%s %d" % (sg, x) for sg, x in terminos[1:])
        pasos.append("     %s = (%s) : %d" % (_u_texto(e), " ".join(arriba), d))
    pasos.extend("     %s" % p for p in res["pasos"])
    if resto:
        pasos.append("     %d y %d/%d%s" % (q, resto, d, "" if q == 0 else " = %s" % _nu_texto(v)))
    pasos.append("     compruebo: %s" % res["vuelta"])
    if r["pieza"]["id"] == "juntar_sobre_el_divisor_comun":
        pasos.append("     OJO: los divisores NO se juntan: se reparte entre %d todas las veces" % d)
    pasos.append("%s = %s" % (_u_texto(e), _nu_texto(v)))
    return v


def _u_en_fila(e, fila):
    """Las hojas y los signos en el orden en que se escriben (un parentesis es una hoja).  False si hay letras o '-'
    de delante (ahi no se ensena el error)."""
    if e[0] == "op":
        return _u_en_fila(e[2], fila) and fila.append(e[1]) is None and _u_en_fila(e[3], fila)
    if e[0] in ("letra", "neg"):
        return False
    fila.append(e)
    return True


def _u_ojo_izquierda(e, v, saber):
    """M.22 (NCETM 2.28): el ERROR TIPICO, ir de izquierda a derecha sin mirar (20 - 12 : 4 como (20 - 12) : 4).  Solo
    si hay una division detras de una + o una - sin parentesis.  Las lineas que lo ensenan (calculado con el mecanismo)."""
    fila = []
    if not _u_en_fila(e, fila) or ":" not in fila:
        return []
    signos = [x for x in fila if isinstance(x, str)]
    if not any(signos[i] in "+-" and signos[i + 1] in _U_FUERTES for i in range(len(signos) - 1)):
        return []
    mal = fila[0]
    for k in range(1, len(fila), 2):
        junto = mal[0] == "op" and mal[1] in "+-" and fila[k] in _U_FUERTES
        mal = ("op", fila[k], ("par", mal) if junto else mal, fila[k + 1])
    try:
        w = _u_simple(_u_valor(mal, saber, []), saber, [])
        if _nu_iguales(w, v, saber):
            return []
    except (_UNoSale, _NuNoSale, KeyError):             # no se puede calcular o comparar (el techo): no se ensena
        return []
    return ["OJO: de izquierda a derecha sin mirar, %s, saldria %s: esta MAL (la x y la : van antes que la + y la -; "
            "NCETM 2.28)" % (_u_texto(mal), _nu_texto(w))]


# ------------------------------------------------------------- M.21: la TABLA DE RAZON (NCETM 2.27), con las piezas de 'proporcion'

def _u_fila(e):
    """Un lado de la proporcion: 'a : b' (enteros sin signo, o la letra sola) o una fraccion escrita 'a/b'.
    La fila (a, b), con None donde esta la letra; o None si ese lado no es una fila de la tabla."""
    while e[0] == "par":
        e = e[1]
    if e[0] == "num":
        x = e[1]
        return (x[1], x[2]) if x[0] == "+" and x[3] == "fraccion" else None
    if e[0] != "op" or e[1] != ":":
        return None
    fila = []
    for t in (e[2], e[3]):
        while t[0] == "par":
            t = t[1]
        if t[0] == "letra":
            fila.append(None)
        elif t[0] == "num" and t[1][0] == "+" and t[1][2] == 1 and t[1][3] == "entero":
            fila.append(t[1][1])
        else:
            return None
    return tuple(fila)


def _u_proporcion(rel, saber, pasos):
    """a : b = c : d con UNA letra sola en uno de los cuatro sitios: 'a es a b como c es a d', la TABLA DE RAZON.
    Se pide a las piezas de 'proporcion' (se elige por el costo: entre las filas, dentro de la fila, o pasando por una
    fila mas pequena).  Lo que sale es un entero.  None si no es una proporcion o no sale justa: como antes."""
    f1, f2 = _u_fila(rel[0]), _u_fila(rel[1])
    if f1 is None or f2 is None or (None in f1) == (None in f2):
        return None
    conocida, con_hueco = (f2, f1) if None in f1 else (f1, f2)
    r = aplicar("proporcion", {"conocida": conocida, "con_hueco": con_hueco}, saber)
    if r["conclusion"] != "hecho":
        return None
    res = r["resultado"]
    dichos = ["?" if x is None else "%d" % x for x in f1]
    dichos.extend("?" if x is None else "%d" % x for x in f2)
    dichos.append(r["pieza"]["nombre"])
    pasos.append("LA TABLA DE RAZON (NCETM 2.27): %s es a %s como %s es a %s;  %s" % tuple(dichos))
    pasos.extend("     %s" % p for p in res["pasos"])
    pasos.append("     compruebo: %s" % res["vuelta"])
    return ("+", res["valor"], 1, "entero")


def _u_cuenta(op, a, b, saber, pasos):
    try:
        return _nu_cuenta(op, a, b, saber, pasos)
    except _NuNoSale as ex:
        con = "no_se_puede" if "entre cero" in str(ex) else "todavia_no"
        raise _UNoSale(con, str(ex))


# ------------------------------------------------------------- operador 1: CALCULAR DESPEJANDO

_U_CONTRARIA = {"+": "-", "-": "+", "x": ":", ":": "x"}


def _u_deshacer(e, objetivo, saber, pasos):
    """La letra esta UNA vez dentro de e, y e tiene que valer 'objetivo': se deshace de fuera hacia dentro (E.5)."""
    if e[0] == "letra":
        return objetivo
    if e[0] == "par":
        return _u_deshacer(e[1], objetivo, saber, pasos)
    if e[0] == "neg":
        pasos.append("deshago el '-' de delante: %s = %s" % (_u_texto(e[1]), _nu_texto(_nu_opuesto(objetivo))))
        return _u_deshacer(e[1], _nu_opuesto(objetivo), saber, pasos)
    op, izq, der = e[1], e[2], e[3]
    if _u_letras(izq):
        otro = _u_valor(der, saber, pasos)
        if op == "x" and _nu_es_cero(otro):
            _u_por_cero(objetivo, izq)
        if op == ":" and _nu_es_cero(otro):          # U.4: entre 0 no se reparte (M.3): ningun numero cumple
            raise _UNoSale("ninguna", "%s : 0 no se puede hacer (entre 0 no se reparte): ningun numero cumple"
                           % _u_texto(izq))
        inv = _U_CONTRARIA[op]
        pasos.append("deshago '%s %s': %s = %s %s %s" % (op, _nu_parentesis(otro), _u_texto(izq),
                                                         _nu_parentesis(objetivo), inv, _nu_parentesis(otro)))
        return _u_deshacer(izq, _u_cuenta(inv, objetivo, otro, saber, pasos), saber, pasos)
    otro = _u_valor(izq, saber, pasos)
    if op == "x" and _nu_es_cero(otro):
        _u_por_cero(objetivo, der)
    if op in ("+", "x"):                                 # conmutativas: como si estuviera a la izquierda
        inv = _U_CONTRARIA[op]
        pasos.append("deshago '%s %s': %s = %s %s %s" % (_nu_parentesis(otro), op, _u_texto(der),
                                                         _nu_parentesis(objetivo), inv, _nu_parentesis(otro)))
        nuevo = _u_cuenta(inv, objetivo, otro, saber, pasos)
    else:                                                # otro - der = objetivo  ->  der = otro - objetivo
        if op == ":" and _nu_es_cero(otro):           # A.1: 0 : algo es 0 (o no se puede): no se pasa al otro lado
            _u_cero_entre(objetivo, der, saber)
        pasos.append("%s %s %s = %s, asi que %s = %s %s %s" % (
            _nu_parentesis(otro), op, _u_texto(der), _nu_parentesis(objetivo), _u_texto(der),
            _nu_parentesis(otro), op, _nu_parentesis(objetivo)))
        if op == ":" and _nu_es_cero(objetivo):
            raise _UNoSale("ninguna", "%s : algo nunca da 0 (el de delante no es 0)" % _nu_texto(otro))
        nuevo = _u_cuenta(op, otro, objetivo, saber, pasos)
    return _u_deshacer(der, nuevo, saber, pasos)


def _u_por_cero(objetivo, e):
    """0 x algo es siempre 0 (M.2): si tiene que dar 0, vale cualquiera; si no, ninguno."""
    if _nu_es_cero(objetivo):
        ex = _UNoSale("todavia_no", "0 x %s es 0 siempre: %s puede valer CUALQUIER numero (infinitas; U.2)"
                      % (_u_texto(e), _u_texto(e)))
        ex.siempre = True                                # A.1: cumple con cualquier numero
        raise ex
    raise _UNoSale("ninguna", "0 x %s es 0 siempre, nunca %s: ningun numero cumple" % (_u_texto(e), _nu_texto(objetivo)))


def _u_cero_entre(objetivo, e, saber):
    """A.1: 0 : algo da 0 con CUALQUIER algo que no sea 0, y entre 0 no se reparte (M.3).  Si tiene que dar 0, vale
    cualquier numero menos el que hace 0 a lo de detras (se busca deshaciendo); si tiene que dar otro, ninguno."""
    if not _nu_es_cero(objetivo):
        raise _UNoSale("ninguna", "0 : %s es 0 (o no se puede, si %s es 0), nunca %s: ningun numero cumple"
                       % (_u_texto(e), _u_texto(e), _nu_texto(objetivo)))
    letra = _u_nombre(_u_letras(e)[0])
    try:
        menos = "menos el %s" % _nu_texto(_u_deshacer(e, _NU_CERO, saber, []))
        if e[0] != "letra":
            menos = "%s (que hace 0 a %s)" % (menos, _u_texto(e))
    except _UNoSale as ex:
        if getattr(ex, "siempre", False):            # lo de detras es 0 siempre: 0 : 0 no se puede, nunca
            raise _UNoSale("ninguna", "0 : %s no se puede: %s es 0 siempre (entre 0 no se reparte)"
                           % (_u_texto(e), _u_texto(e)))
        menos = "que no haga 0 (ni imposible) a %s" % _u_texto(e)
    raise _UNoSale("todavia_no", "0 : %s es 0 siempre que %s no sea 0: %s puede valer CUALQUIER numero %s "
                   "(infinitas; todavia no se dar esa respuesta)" % (_u_texto(e), _u_texto(e), letra, menos))


class _UNoLineal(Exception):
    pass


def _u_lineal(e, letra, saber, pasos):
    """Los TROZOS: e = (coef) trozos de la letra + (suelto).  Devuelve (coef, suelto) como numeros.
    Solo si la letra no se multiplica por si misma ni divide (si no, _UNoLineal)."""
    if e[0] == "letra":
        return ("+", 1, 1, "entero"), _NU_CERO
    if not _u_letras(e):
        return _NU_CERO, _u_valor(e, saber, pasos)
    if e[0] == "par":
        return _u_lineal(e[1], letra, saber, pasos)
    if e[0] == "neg":
        c, k = _u_lineal(e[1], letra, saber, pasos)
        return _nu_opuesto(c), _nu_opuesto(k)
    op, izq, der = e[1], e[2], e[3]
    if op in "+-":
        c1, k1 = _u_lineal(izq, letra, saber, pasos)
        c2, k2 = _u_lineal(der, letra, saber, pasos)
        return _u_cuenta(op, c1, c2, saber, pasos), _u_cuenta(op, k1, k2, saber, pasos)
    if op == "x" and not _u_letras(izq):
        v = _u_valor(izq, saber, pasos)
        c, k = _u_lineal(der, letra, saber, pasos)
        return _u_cuenta("x", v, c, saber, pasos), _u_cuenta("x", v, k, saber, pasos)
    if not _u_letras(der):
        v = _u_valor(der, saber, pasos)
        c, k = _u_lineal(izq, letra, saber, pasos)
        return _u_cuenta(op, c, v, saber, pasos), _u_cuenta(op, k, v, saber, pasos)
    raise _UNoLineal("%s se multiplica o se divide por si misma" % _u_nombre(letra))


def _u_despejar(rel, letra, saber, pasos):
    """Operador 1.  La unica letra que falta en la relacion: deshaciendo (si sale una vez) o contando trozos."""
    izq, der = rel
    veces = len(_u_letras_rel(rel))
    if veces == 1:
        p = _u_proporcion(rel, saber, pasos)            # M.21: a : b = c : ?, la tabla de razon (NCETM 2.27)
        if p is not None:
            return p
        con, sin = (izq, der) if _u_letras(izq) else (der, izq)
        objetivo = _u_valor(sin, saber, pasos)
        if con[0] == "letra":
            return objetivo
        pasos.append("deshago de fuera hacia dentro (trabajar hacia atras): %s = %s"
                     % (_u_texto(con), _nu_texto(objetivo)))
        return _u_deshacer(con, objetivo, saber, pasos)
    pasos.append("%s sale %d veces: cuento los TROZOS de %s (la barra)" % (_u_nombre(letra), veces, _u_nombre(letra)))
    try:
        c1, k1 = _u_lineal(izq, letra, saber, [])
        c2, k2 = _u_lineal(der, letra, saber, [])
    except _UNoLineal as ex:
        raise _UNoSale("todavia_no", "%s: todavia no (eso es probar en orden, U.2)" % ex)
    for lado, c_, k_ in ((izq, c1, k1), (der, c2, k2)):
        pasos.append("%s  es  %s" % (_u_texto(lado), _u_trozos_texto(c_, k_, letra)))
    sub = []
    c = _u_cuenta("-", c1, c2, saber, sub) if not _nu_es_cero(c2) else c1
    if c[0] == "-":                              # los trozos se QUITAN: son lo que va de lo de un lado a lo del otro
        c = _nu_opuesto(c)
        k = _u_cuenta("-", k1, k2, saber, sub) if not _nu_es_cero(k2) else k1
        nota = "los trozos se QUITAN: son lo que va de %s a %s" % (_nu_texto(k2), _nu_texto(k1))
    else:
        k = _u_cuenta("-", k2, k1, saber, sub) if not _nu_es_cero(k1) else k2
        nota = "los trozos a un lado y lo suelto al otro"
    if sub:
        pasos.append(nota + ":")
        pasos.extend(sub)
    if _nu_es_cero(c):
        if _nu_es_cero(k):
            raise _UNoSale("todavia_no", "los trozos de %s se van: vale CUALQUIER numero (infinitas; U.2)"
                           % _u_nombre(letra))
        raise _UNoSale("ninguna", "los trozos de %s se van y queda %s = 0: ningun numero cumple"
                       % (_u_nombre(letra), _nu_texto(k)))
    pasos.append("junto: %s trozos de %s = %s" % (_nu_texto(c), _u_nombre(letra), _nu_texto(k)))
    if _nu_iguales(c, ("+", 1, 1, "entero"), saber):
        return k
    pasos.append("un trozo: %s : %s" % (_nu_parentesis(k), _nu_parentesis(c)))
    return _u_cuenta(":", k, c, saber, pasos)


# ------------------------------------------------------------- operador 2: SUSTITUIR

def _u_aislar(e, objetivo, letra):
    """Como _u_deshacer, pero con letras: e (con la letra UNA vez) = objetivo (un arbol) -> letra = arbol."""
    def par(x):
        return x if x[0] in ("num", "letra", "par") else ("par", x)
    while e[0] != "letra":
        if e[0] == "par":
            e = e[1]
            continue
        if e[0] == "neg":
            e, objetivo = e[1], ("neg", par(objetivo))
            continue
        op, izq, der = e[1], e[2], e[3]
        if letra in _u_letras(izq):
            if op == "x" and _u_puede_ser_cero(der) and _u_puede_ser_cero(objetivo):
                return None                              # A.1: (0 : 0) no se aisla; 0 x algo = 0 vale con cualquiera
            e, objetivo = izq, ("op", _U_CONTRARIA[op], par(objetivo), par(der))
        elif op in ("x", ":") and _u_puede_ser_cero(izq) and _u_puede_ser_cero(objetivo):
            return None                                  # A.1: lo mismo con la letra detras (0 : algo = 0)
        elif op in ("+", "x"):
            e, objetivo = der, ("op", _U_CONTRARIA[op], par(objetivo), par(izq))
        else:
            e, objetivo = der, ("op", op, par(izq), par(objetivo))
    return objetivo


def _u_puede_ser_cero(e):
    """A.1: un arbol que podria valer 0 (todo lo que no es un numero escrito distinto de 0).  Aislar pasando a DIVIDIR
    entre algo asi, cuando lo de delante tambien podria ser 0, haria 0 : 0 y perderia soluciones."""
    while e[0] in ("par", "neg"):
        e = e[1]
    return e[0] != "num" or _nu_es_cero(e[1])


def _u_elegir_para_sustituir(rels):
    """La relacion y la letra: primero una letra SOLA en un lado (x = y); si no, una que salga UNA vez."""
    orden = sorted(range(len(rels)), key=lambda i: len(_u_distintas(_u_letras_rel(rels[i]))))
    for i in orden:
        izq, der = rels[i]
        for lado, otro in ((izq, der), (der, izq)):
            if lado[0] == "letra" and lado[1] not in _u_letras(otro):
                return i, lado[1], otro, "sola"
    for i in orden:
        todas = _u_letras_rel(rels[i])
        for letra in _u_distintas(todas):
            if todas.count(letra) == 1:
                izq, der = rels[i]
                con, sin = (izq, der) if letra in _u_letras(izq) else (der, izq)
                arbol = _u_aislar(con, sin, letra)
                if arbol is not None:
                    return i, letra, arbol, "aislada"
    return None


# ------------------------------------------------------------- el resolvedor: el bucle con presupuesto

def _u_trozos_texto(c, k, letra):
    """'2 trozos de b y 1/2 suelto';  con trozos en negativo: '1/2 quitando 2 trozos de b'."""
    n = _u_nombre(letra)
    if _nu_es_cero(c):
        return "%s suelto" % _nu_texto(k)
    trozos = "%s %s de %s" % (_nu_texto(c).lstrip("-"), "trozo" if _nu_texto(c).lstrip("-") == "1" else "trozos", n)
    if _nu_es_cero(k):
        return trozos if c[0] == "+" else "0 quitando %s" % trozos
    if c[0] == "+":
        return "%s y %s suelto" % (trozos, _nu_texto(k))
    return "%s quitando %s" % (_nu_texto(k), trozos)


def _u_presupuesto(saber):
    t = str((saber.get("universal") or {}).get("presupuesto_de_pasos", "20"))
    return int(t) if t.isdigit() else 20


def decidir_resolver(texto, saber=None):
    if saber is None:
        saber = cargar_conocimiento()
    r = {"texto": texto, "etapas": []}
    try:
        modelo = _u_leer(texto)
    except _NuNoSale as ex:
        r.update(conclusion="todavia_no", porque=str(ex))
        return r
    except (ValueError, IndexError) as ex:
        if not re.search(r"[a-z]{3,}", _u_limpio(texto)):
            r.update(conclusion="no_entiendo", porque=str(ex))
            return r
        try:                                     # con palabras: el lector de palabras (U.3) da el MISMO modelo
            modelo = _pa_leer(texto, saber)
        except (ValueError, IndexError, KeyError, _NuNoSale) as ex2:
            r.update(conclusion="no_entiendo", porque=str(ex2))
            return r
    r["modelo"] = modelo
    try:
        if modelo["expresion"] is not None:
            pasos = []
            v = _u_simple(_u_valor(modelo["expresion"], saber, pasos), saber, pasos)
            pasos.extend(_u_ojo_izquierda(modelo["expresion"], v, saber))
            r["etapas"].append(("CALCULO en el orden de siempre (primero x y :, luego + y -)", pasos))
            r.update(conclusion="hecho", valor=v, respuesta=_nu_texto(v))
            _u_tambien_decimal(r, v, modelo, saber)
            return r
        valores = _u_buscar(modelo, saber, r)
    except _UNoSale as ex:
        r.update(conclusion=ex.conclusion, porque=ex.porque)
        return r
    except KeyError as ex:                       # un numero sin nombre (pasa del techo)
        r.update(conclusion="todavia_no", porque="un numero se pasa de mi techo (%s): %s" % (techo(saber), ex))
        return r
    if valores is None:                          # relaciones sin letras: verdad o no
        return r
    if r.get("probado"):                         # probar en orden (U.2): una, varias o ninguna
        return _u_probado(r, valores, modelo, saber)
    sub = []
    valores = dict((l, _u_simple(v, saber, sub)) for l, v in valores.items())
    if sub:
        r["etapas"].append(("ESCRIBO la respuesta en su forma mas simple (F.6)", sub))
    r["valores"] = valores
    try:
        _u_comprobar(modelo, valores, saber, r)
    except _NuNoSale as ex:                      # M.21 (arreglo): no se puede comprobar (falta una tabla): no es 'no entiendo'
        r.update(conclusion="todavia_no", porque="no lo puedo comprobar todavia: %s" % ex)
        return r
    raro = _pa_razonable(valores, modelo, saber) if modelo.get("palabras") and r["comprobacion_ok"] else None
    if raro:                                     # capa 4: cuadra, pero no es razonable (E.6)
        r.update(conclusion="no_razonable", porque=raro)
    elif r["comprobacion_ok"]:
        r["conclusion"] = "hecho"
        r["respuesta"] = _u_escribir_valores(valores, modelo)
    else:
        r.update(conclusion="no_cuadra", porque="al poner los numeros en las relaciones de partida no cuadra")
    return r


def _u_simple(v, saber, pasos):
    """Una fraccion que se lee tal cual (n = 12/3) se dice en su forma mas simple (F.6), como las que salen de cuentas."""
    if v[3] != "fraccion":
        return v
    try:
        return _nu_simple(v, saber, pasos)
    except (_NuNoSale, KeyError):
        return v


def _u_escribir_valores(valores, modelo):
    if modelo.get("pide"):                       # con palabras (U.3): solo lo que se pide, con su unidad
        return _pa_respuesta(valores, modelo)
    return ", ".join("%s = %s" % (_u_nombre(l), _nu_texto(valores[l])) for l in modelo["cantidades"])


def _u_probado(r, soluciones, modelo, saber):
    """Las soluciones de probar en orden (cada una ya comprobada en TODAS las relaciones de partida)."""
    lineas, ok = [], True
    for v in soluciones:
        sub = {}
        _u_comprobar(modelo, v, saber, sub)
        lineas.extend(sub["comprobacion"])
        ok = ok and sub["comprobacion_ok"]
    r["comprobacion"] = lineas
    r["comprobacion_ok"] = ok
    r["cuantas"] = "ninguna" if not soluciones else ("una" if not soluciones[1:] else "varias")
    r["nota"] = "con numeros para contar, desde el 0"
    if viene_despues(decir(len(modelo["cantidades"]), saber), decir(len(modelo["relaciones"]), saber), saber):
        r["nota"] = "%s; con decimales o fracciones habria infinitas (falta una relacion que las pare)" % r["nota"]
    if not ok:
        r.update(conclusion="no_cuadra", porque="al poner los numeros en las relaciones de partida no cuadra")
    elif not soluciones:
        r.update(conclusion="ninguna", porque="probe en orden y ninguna cumple (%s)" % r["nota"])
    else:
        r.update(conclusion="hecho", respuesta="; ".join(_u_escribir_valores(v, modelo) for v in soluciones))
    return r


def _u_tambien_decimal(r, v, modelo, saber):
    """Si en el enunciado habia decimales y la respuesta es una fraccion, se dice tambien en decimal si sale justo."""
    if v[3] == "fraccion" and v[2] != 1 and re.search(r"\d[.,]\d", modelo["texto"]):
        d = _nu_en_decimas(v, saber, [])
        if d is not None:
            r["tambien"] = "%s = %s" % (_nu_texto(v), _nu_texto(d))


def _u_buscar(modelo, saber, r):
    """Los operadores, por turnos, hasta saberlo todo (o hasta agotar el presupuesto)."""
    rels = list(modelo["relaciones"])
    if not modelo["cantidades"]:                 # sin letras: es una igualdad (E.0): verdad o no
        pasos, ok = [], True
        for izq, der in rels:
            vi, vd = _u_valor(izq, saber, pasos), _u_valor(der, saber, pasos)
            ok = ok and _nu_iguales(vi, vd, saber)
        r["etapas"].append(("CALCULO cada lado", pasos))
        r.update(conclusion="hecho", respuesta="VERDADERO" if ok else "FALSO", verdad=ok)
        return None
    rels, siempre = _bu_identidades(rels, saber, r["etapas"])                # U.4: identidades y contradicciones
    originales = [x for x in modelo["relaciones"] if x not in siempre]
    soluciones = _bu_resolver(rels, saber, r["etapas"], originales)          # U.2: buscar con control
    probado = any(t.startswith("PRUEBO EN ORDEN") for t, _ in r["etapas"])
    if not probado:
        faltan = [l for l in (modelo.get("pide") or modelo["cantidades"]) if l not in soluciones[0]]
        if faltan:
            raise _UNoSale("todavia_no", "faltan relaciones: %s puede valer cualquier cosa (infinitas)"
                           % ", ".join(_u_nombre(l) for l in faltan))
        return soluciones[0]
    faltan = [l for l in (modelo.get("pide") or modelo["cantidades"]) if soluciones and l not in soluciones[0]]
    if faltan:                                   # una letra que solo salia en una identidad (U.4): puede ser cualquiera
        raise _UNoSale("todavia_no", "faltan relaciones: %s puede valer cualquier cosa (infinitas)"
                       % ", ".join(_u_nombre(l) for l in faltan))
    r["probado"] = True
    r["soluciones"] = soluciones
    return soluciones


# ------------------------------------------------------------- 4. COMPROBAR en las relaciones de partida

def _u_comprobar(modelo, valores, saber, r):
    lineas, ok = [], True
    for rel in modelo["relaciones"]:
        pasos = []
        try:
            izq, der = _u_poner_todas(rel[0], valores), _u_poner_todas(rel[1], valores)
            vi, vd = _u_valor(izq, saber, pasos), _u_valor(der, saber, pasos)
            bien = _nu_iguales(vi, vd, saber)
            lineas.append("%s  ->  %s = %s  ->  %s = %s ... %s" % (_u_rel_texto(rel), _u_texto(izq), _u_texto(der),
                                                                  _nu_texto(vi), _nu_texto(vd), "SI" if bien else "NO"))
        except _UNoSale as ex:
            bien = _u_comprobar_deshaciendo(rel, valores, saber, lineas, ex)
        ok = ok and bien
    r["comprobacion"] = lineas
    r["comprobacion_ok"] = ok


def _u_comprobar_deshaciendo(rel, valores, saber, lineas, ex):
    """M.17: un lado no se puede calcular todavia (8544 : 24 es la division larga, 2.24).  Un humano lo comprueba
    DESHACIENDO desde el otro lado (lo que se suma se resta, lo que se divide se multiplica: 8544 : 24 = 356 porque
    356 x 24 = 8544; dividir es lo contrario de multiplicar, NCETM 2.6, 3.OA.B.6) hasta el trozo que no se podia."""
    izq, der = _u_poner_todas(rel[0], valores), _u_poner_todas(rel[1], valores)
    for lado, otro in ((izq, der), (der, izq)):
        pasos = []
        try:
            v = _u_valor(otro, saber, [])
            bien = _u_cuadra_deshaciendo(lado, v, saber, pasos)
        except _UNoSale:
            continue
        lineas.append("%s  ->  %s = %s  ->  %s no lo puedo calcular (%s); lo compruebo DESHACIENDO desde %s: %s ... %s"
                      % (_u_rel_texto(rel), _u_texto(izq), _u_texto(der), _u_texto(lado), ex.porque, _nu_texto(v),
                         "; ".join(pasos), "SI" if bien else "NO"))
        return bien
    lineas.append("%s  ->  no lo puedo calcular (%s)" % (_u_rel_texto(rel), ex.porque))
    return False


def _u_cuadra_deshaciendo(e, v, saber, pasos):
    """El arbol e (sin letras) vale v?  Si se puede calcular, se calcula; si no, se deshace su ultima cuenta desde v."""
    try:
        return _nu_iguales(_u_valor(e, saber, []), v, saber)
    except _UNoSale:
        if e[0] == "par":
            return _u_cuadra_deshaciendo(e[1], v, saber, pasos)
        if e[0] != "op":
            raise
    op, izq, der = e[1], e[2], e[3]
    if op == ":":                                # izq : der = v  <->  izq = v x der
        d = _u_valor(der, saber, [])
        if _nu_es_cero(d):
            raise _UNoSale("no_se_puede", "entre cero no se reparte")
        w = _u_cuenta("x", v, d, saber, [])
        pasos.append("%s : %s = %s porque %s x %s = %s" % (_u_texto(izq), _nu_texto(d), _nu_texto(v), _nu_texto(v),
                                                           _nu_texto(d), _nu_texto(w)))
        return _u_cuadra_deshaciendo(izq, w, saber, pasos)
    try:
        k, falta, a_la_derecha = _u_valor(der, saber, []), izq, True
    except _UNoSale:
        k, falta, a_la_derecha = _u_valor(izq, saber, []), der, False
    if op == "+":
        w = _u_cuenta("-", v, k, saber, [])
    elif op == "x":
        w = _u_cuenta(":", v, k, saber, [])
    elif a_la_derecha:                           # falta - k = v  ->  falta = v + k
        w = _u_cuenta("+", v, k, saber, [])
    else:                                        # k - falta = v  ->  falta = k - v
        w = _u_cuenta("-", k, v, saber, [])
    pasos.append("deshago '%s %s': %s tiene que ser %s" % (op, _nu_texto(k), _u_texto(falta), _nu_texto(w)))
    return _u_cuadra_deshaciendo(falta, w, saber, pasos)


# ------------------------------------------------------------- explicar

def explicar_resolver(texto, saber=None):
    if saber is None:
        saber = cargar_conocimiento()
    r = decidir_resolver(texto, saber)
    if r["conclusion"] == "no_entiendo":
        return ("NO ENTIENDO ESTO: %s\n   se escribe asi:  resolver: a + b = 1/2; a - b = 1/4     resolver: 3 x n = 4.5"
                "     1/2 + 0.25     -3 + 2 x 4" % r.get("porque", ""))
    m = r.get("modelo")
    if m and m.get("palabras"):
        L = ["PREGUNTA (U.3, el lector de palabras; U.1-U.2, el resolvedor): %s" % m["texto"], ""]
        L.extend(_pa_explicar_lectura(m, saber))
    else:
        L = ["PREGUNTA (U.1-U.2, el resolvedor): %s" % _u_limpio(texto), ""]
    if m:
        L.append("  EL MODELO:")
        if m["expresion"] is not None:
            L.append("     una cuenta para calcular: %s" % _u_texto(m["expresion"]))
        else:
            L.append("     lo que falta: %s" % (", ".join(_u_nombre(l) for l in m["cantidades"]) or "nada (es una igualdad)"))
            for k, rel in enumerate(m["relaciones"]):
                L.append("     relacion %d: %s" % (_u_siguiente(k, saber), _u_rel_texto(rel)))
            L.append("     se pide: %s" % (", ".join(_u_nombre(l) for l in (m.get("pide") or m["cantidades"]))
                                         or "si es verdad"))
        L.append("")
    for k, (titulo, pasos) in enumerate(r["etapas"]):
        L.append("  %d. %s" % (_u_siguiente(k, saber), titulo))
        for p in pasos:
            L.append("        %s" % p)
    if r.get("comprobacion"):
        L.append("")
        L.append("  COMPRUEBO en las relaciones de PARTIDA:")
        for c in r["comprobacion"]:
            L.append("        %s" % c)
    if r.get("tambien"):
        L.append("")
        L.append("  en decimal: %s" % r["tambien"])
    if r.get("cuantas"):
        L.append("")
        L.append("  CUANTAS: %s (%s)" % (r["cuantas"].upper(), r["nota"]))
    L.append("")
    if r["conclusion"] == "hecho":
        L.append("RESULTADO: %s" % r["respuesta"])
    else:
        etiqueta = {"ninguna": "NINGUNA", "no_se_puede": "NO SE PUEDE", "no_cuadra": "NO CUADRA",
                    "cualquiera": "CUALQUIER NUMERO",
                    "no_razonable": "NO ES RAZONABLE"}.get(
            r["conclusion"], "TODAVIA NO")
        L.append("  %s: %s" % (etiqueta, r.get("porque", "")))
        L.append("")
        L.append("RESULTADO: %s" % r["conclusion"])
    return "\n".join(L)


def explicar_orden_resolver(texto, saber=None):
    return explicar_resolver(texto, saber)


def _u_siguiente(k, saber):
    """k + 1, recitando (el siguiente en la lista): para numerar los pasos."""
    return leer(siguiente(decir(k, saber), saber), saber)
